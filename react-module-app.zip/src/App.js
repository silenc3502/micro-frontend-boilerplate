import React from "react";
import { Counter } from "./components/Counter";

const App = () => (
  <div className="container">
    <Counter />
  </div>
);

export { App }